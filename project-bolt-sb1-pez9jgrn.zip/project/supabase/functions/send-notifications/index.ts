/*
  # Send Notifications Function
  
  Sends email and push notifications for task assignments and updates
  
  1. Functionality
    - Sends email notifications for task assignments
    - Sends overdue task alerts
    - Sends task completion confirmations
    - Handles push notifications via web push API
    
  2. Security
    - Validates user authentication
    - Checks notification preferences
*/

import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface NotificationRequest {
  type: 'task_assigned' | 'task_overdue' | 'task_completed' | 'general';
  recipientEmail?: string;
  recipientId?: string;
  taskId?: string;
  message: string;
  title: string;
  priority?: 'low' | 'medium' | 'high';
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { type, recipientEmail, recipientId, taskId, message, title, priority = 'medium' }: NotificationRequest = await req.json();

    if (!type || !message || !title) {
      return new Response(
        JSON.stringify({ error: 'Missing required fields: type, message, title' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get environment variables
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    const fromEmail = 'onboarding@resend.dev';
    
    console.log('Notification request:', { type, recipientEmail, recipientId, taskId, priority });

    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: 'Missing Supabase configuration' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get recipient details if only ID provided
    let targetEmail = recipientEmail;
    if (!targetEmail && recipientId) {
      const { data: teamMember } = await supabase
        .from('team')
        .select('"Email"')
        .eq('id', recipientId)
        .single();
      
      targetEmail = teamMember?.["Email"];
    }

    if (!targetEmail) {
      return new Response(
        JSON.stringify({ error: 'No recipient email found' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get task details if provided
    let taskDetails = null;
    if (taskId) {
      const { data: task } = await supabase
        .from('tasks')
        .select(`
          *,
          assets("Asset Name", "Asset Type"),
          plant_rooms("Block", "Address")
        `)
        .eq('id', taskId)
        .single();
      
      taskDetails = task;
    }

    // Generate email content based on notification type
    let emailSubject = title;
    let emailHtml = generateEmailHTML(type, message, taskDetails);

    // Send email notification if Resend is configured
    let emailResult = null;
    if (resendApiKey) {
      try {
        const emailData = {
          from: fromEmail,
          to: [targetEmail],
          subject: emailSubject,
          html: emailHtml
        };

        const resendResponse = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${resendApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(emailData)
        });

        emailResult = await resendResponse.json();
        
        if (!resendResponse.ok) {
          console.error('Resend API error:', emailResult);
        } else {
          console.log('Email sent successfully:', emailResult.id);
        }
      } catch (emailError) {
        console.error('Error sending email:', emailError);
      }
    }

    // Store notification in database for in-app notifications
    const { error: notificationError } = await supabase
      .from('notifications')
      .insert([{
        recipient_id: recipientId,
        recipient_email: targetEmail,
        type,
        title,
        message,
        task_id: taskId,
        priority,
        sent_at: new Date().toISOString(),
        email_sent: !!emailResult && !emailResult.error,
        read: false
      }]);

    if (notificationError) {
      console.error('Error storing notification:', notificationError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Notification sent successfully',
        emailSent: !!emailResult && !emailResult.error,
        emailResult: emailResult || 'Email service not configured'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in send-notifications function:', error);
    return new Response(
      JSON.stringify({ error: `Internal server error: ${error.message}` }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

function generateEmailHTML(type: string, message: string, taskDetails?: any): string {
  const getTypeColor = (notificationType: string) => {
    switch (notificationType) {
      case 'task_assigned': return '#0d9488';
      case 'task_overdue': return '#ef4444';
      case 'task_completed': return '#22c55e';
      default: return '#3b82f6';
    }
  };

  const getTypeTitle = (notificationType: string) => {
    switch (notificationType) {
      case 'task_assigned': return 'New Task Assigned';
      case 'task_overdue': return 'Task Overdue Alert';
      case 'task_completed': return 'Task Completed';
      default: return 'Notification';
    }
  };

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Mech Hub Notification</title>
      <style>
        body { 
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
          margin: 0; 
          padding: 20px; 
          background-color: #f8fafc;
          color: #1e293b;
          line-height: 1.6;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background: white;
          padding: 30px;
          border-radius: 16px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .header { 
          text-align: center;
          border-bottom: 3px solid ${getTypeColor(type)}; 
          padding-bottom: 20px; 
          margin-bottom: 25px; 
        }
        .title { 
          color: ${getTypeColor(type)}; 
          margin: 0; 
          font-size: 28px; 
          font-weight: bold; 
        }
        .subtitle { 
          color: #64748b; 
          margin: 8px 0 0 0; 
          font-size: 16px;
        }
        .content {
          margin: 20px 0;
        }
        .message {
          font-size: 18px;
          color: #1e293b;
          margin-bottom: 25px;
          padding: 20px;
          background: linear-gradient(135deg, #f0fdfa, #f7fee7);
          border-radius: 12px;
          border-left: 4px solid ${getTypeColor(type)};
        }
        .task-details {
          background: #f8fafc;
          padding: 20px;
          border-radius: 12px;
          margin: 20px 0;
        }
        .detail-row {
          display: flex;
          justify-content: space-between;
          margin: 10px 0;
          padding: 8px 0;
          border-bottom: 1px solid #e5e7eb;
        }
        .detail-label {
          font-weight: 600;
          color: #374151;
        }
        .detail-value {
          color: #1e293b;
        }
        .cta-button {
          display: inline-block;
          padding: 15px 30px;
          background: linear-gradient(135deg, ${getTypeColor(type)}, ${getTypeColor(type)}dd);
          color: white;
          text-decoration: none;
          border-radius: 12px;
          font-weight: 600;
          margin: 20px 0;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .footer { 
          margin-top: 40px; 
          padding-top: 20px; 
          border-top: 2px solid #e5e7eb; 
          text-align: center; 
          color: #64748b; 
          font-size: 14px; 
        }
        @media (max-width: 600px) {
          .container {
            padding: 20px;
            margin: 10px;
          }
          .detail-row {
            flex-direction: column;
          }
          .detail-label {
            margin-bottom: 5px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1 class="title">${getTypeTitle(type)}</h1>
          <p class="subtitle">Mech Hub Plant Room Management</p>
        </div>
        
        <div class="content">
          <div class="message">
            ${message}
          </div>
          
          ${taskDetails ? `
          <div class="task-details">
            <h3 style="margin-top: 0; color: #1e293b;">Task Details</h3>
            <div class="detail-row">
              <span class="detail-label">Task ID:</span>
              <span class="detail-value">${taskDetails.task_id}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Asset:</span>
              <span class="detail-value">${taskDetails.assets?.["Asset Name"] || 'General Task'}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Location:</span>
              <span class="detail-value">${taskDetails.plant_rooms?.["Block"] || 'Unknown'}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Due Date:</span>
              <span class="detail-value">${new Date(taskDetails.due_date).toLocaleDateString()}</span>
            </div>
            <div class="detail-row">
              <span class="detail-label">Priority:</span>
              <span class="detail-value">${taskDetails.priority}</span>
            </div>
          </div>
          
          <div style="text-align: center;">
            <a href="${Deno.env.get('SUPABASE_URL')}/tasks/${taskDetails.id}" class="cta-button">
              View Task Details
            </a>
          </div>
          ` : ''}
        </div>

        <div class="footer">
          <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
          <p><strong>System:</strong> Mech Hub Plant Room Management</p>
          <p style="margin-top: 15px; font-size: 12px;">
            This notification was sent automatically. Please do not reply to this email.
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}