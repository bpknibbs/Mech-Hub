/*
  # Fetch Upcoming Tasks Function
  
  Proxies upcoming tasks queries through Edge Function to bypass webcontainer network restrictions
  
  1. Functionality
    - Fetches tasks due within the next 7 days
    - Returns task details with asset and location information
    - Filters by open status only
    
  2. Security
    - Uses service role for database access
    - Returns limited task information for dashboard view
*/

import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing environment variables:', { 
        hasUrl: !!supabaseUrl, 
        hasServiceKey: !!supabaseServiceKey 
      });
      return new Response(
        JSON.stringify({ error: 'Missing Supabase configuration' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    let supabase;
    
    try {
      supabase = createClient(supabaseUrl, supabaseServiceKey);
    } catch (initError) {
      console.error('Error initializing client:', initError);
      return new Response(
        JSON.stringify({ error: 'Failed to initialize database client' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    console.log('Fetching upcoming tasks...');

    const today = new Date();
    const nextWeek = new Date(today.getTime() + (7 * 24 * 60 * 60 * 1000));

    let data, error;
    
    try {
      const result = await supabase
        .from('tasks')
        .select(`
          id,
          task_id,
          type_of_task,
          due_date,
          priority,
          status,
          assets("Asset Name"),
          plant_rooms("Block")
        `)
        .eq('status', 'Open')
        .gte('due_date', today.toISOString().split('T')[0])
        .lte('due_date', nextWeek.toISOString().split('T')[0])
        .order('due_date', { ascending: true })
        .limit(5);
      
      data = result.data;
      error = result.error;
    } catch (queryError) {
      console.error('Database query error:', queryError);
      return new Response(
        JSON.stringify({ 
          error: `Database query failed: ${queryError.message}`,
          success: false 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (error) {
      console.error('Error fetching upcoming tasks:', error);
      return new Response(
        JSON.stringify({ 
          error: `Database error: ${error.message}`,
          success: false 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        data: data || []
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in fetch-upcoming-tasks function:', error);
    return new Response(
      JSON.stringify({ 
        error: `Internal server error: ${error.message}`,
        success: false 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});