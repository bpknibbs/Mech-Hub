/*
  # Generate PDF Email Function
  
  Creates PDF from form submission data and sends via email using Resend
  
  1. Functionality
    - Generates PDF from form submission responses
    - Includes signatures and photos
    - Sends PDF as email attachment using Resend API
    - Updates submission record with email status
    
  2. Security
    - Validates user authentication
    - Checks submission access permissions
*/

import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface FormSubmission {
  id: string;
  form_submission_id: string;
  task_id?: string;
  asset_id?: string;
  engineer_id?: string;
  submission_date: string;
  responses: any;
  photos?: string[];
  engineer_signature?: string;
  client_signature?: string;
  status: string;
  assets?: {
    "Asset Name": string;
    "Asset ID": string;
    "Asset Type": string;
  };
  team?: {
    "Name": string;
    "Email": string;
  };
  tasks?: {
    task_id: string;
    type_of_task: string;
  };
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { submissionId, emailAddress } = await req.json();

    if (!submissionId || !emailAddress) {
      return new Response(
        JSON.stringify({ error: 'Missing submissionId or emailAddress' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Get environment variables
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    const fromEmail = 'onboarding@resend.dev'; // Use verified Resend domain
    
    console.log('Environment check:', { 
      hasUrl: !!supabaseUrl, 
      hasServiceKey: !!supabaseServiceKey,
      hasResendKey: !!resendApiKey,
      fromEmail,
      submissionId,
      emailAddress 
    });

    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: 'Missing Supabase configuration' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!resendApiKey) {
      return new Response(
        JSON.stringify({ 
          error: 'Email service not configured. Please add RESEND_API_KEY to edge function secrets.' 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Initialize Supabase client
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch submission details with proper relationships
    const { data: submissionData, error: submissionError } = await supabase
      .from('form_submissions')
      .select(`
        *,
        assets("Asset Name", "Asset ID", "Asset Type"),
        team("Name", "Email"),
        tasks(task_id, type_of_task)
      `)
      .eq('id', submissionId)
      .single();

    if (submissionError) {
      console.error('Failed to fetch submission:', submissionError);
      return new Response(
        JSON.stringify({ error: `Failed to fetch submission: ${submissionError.message}` }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!submissionData) {
      return new Response(
        JSON.stringify({ error: 'Submission not found' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const submission: FormSubmission = submissionData;

    // Fetch plant room data separately through tasks relationship
    let plantRoomData = null;
    if (submission.task_id) {
      const { data: taskWithPlantRoom } = await supabase
        .from('tasks')
        .select('plant_rooms("Block", "Address")')
        .eq('id', submission.task_id)
        .single();
      
      plantRoomData = taskWithPlantRoom?.plant_rooms;
    }

    console.log('Processing submission for email:', submission.form_submission_id);

    // Generate PDF HTML content
    const pdfHtml = generatePDFHTML(submission, plantRoomData);

    // Send email using Resend
    try {
      const emailData = {
        from: fromEmail,
        to: [emailAddress],
        subject: `Form Submission Report - ${submission.form_submission_id}`,
        html: `
          <h2>Form Submission Report</h2>
          <p>Please find attached the form submission report for:</p>
          <ul>
            <li><strong>Submission ID:</strong> ${submission.form_submission_id}</li>
            <li><strong>Asset:</strong> ${submission.assets?.["Asset Name"] || 'General'}</li>
            <li><strong>Engineer:</strong> ${submission.team?.["Name"] || 'Unknown'}</li>
            <li><strong>Date:</strong> ${new Date(submission.submission_date).toLocaleDateString()}</li>
          </ul>
          <p>The detailed report is included as a PDF attachment.</p>
          <hr>
          <p style="font-size: 12px; color: #666;">Generated by Mech Hub Plant Room Management System</p>
        `,
        attachments: [
          {
            filename: `form-submission-${submission.form_submission_id}.html`,
            content: btoa(unescape(encodeURIComponent(pdfHtml))),
            type: 'text/html',
            disposition: 'attachment'
          }
        ]
      };

      console.log('Sending email via Resend...');
      
      const resendResponse = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(emailData)
      });

      const resendResult = await resendResponse.json();
      
      console.log('Resend API response:', {
        status: resendResponse.status,
        result: resendResult
      });

      if (!resendResponse.ok) {
        console.error('Resend API error:', resendResult);
        
        // Handle domain verification error specifically
        if (resendResult.name === 'validation_error' && (resendResult.error?.includes('domain is not verified') || resendResult.error?.includes('You can only send testing emails'))) {
          return new Response(
            JSON.stringify({ 
              error: 'Testing mode limitation',
              details: resendResult
            }),
            { 
              status: 400, 
              headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
            }
          );
        }
        
        return new Response(
          JSON.stringify({ 
            error: `Failed to send email: ${resendResult.message || 'Unknown error'}`,
            details: resendResult
          }),
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        );
      }

      console.log('Email sent successfully via Resend:', resendResult.id);

      // Update the submission record with email details
      const { error: updateError } = await supabase
        .from('form_submissions')
        .update({
          emailed_to: [...(submission.emailed_to || []), emailAddress],
          pdf_url: `data:text/html;base64,${btoa(unescape(encodeURIComponent(pdfHtml)))}`
        })
        .eq('id', submissionId);

      if (updateError) {
        console.error('Failed to update submission record:', updateError);
        // Don't fail the whole request if we can't update the record
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Email sent successfully!',
          emailedTo: emailAddress,
          resendId: resendResult.id
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );

    } catch (emailError) {
      console.error('Error sending email:', emailError);
      return new Response(
        JSON.stringify({ 
          error: `Failed to send email: ${emailError.message}`,
          isDemo: false
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

  } catch (error) {
    console.error('Error in generate-pdf-email function:', error.message, error.stack);
    return new Response(
      JSON.stringify({ error: `Internal server error: ${error.message}` }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

function generatePDFHTML(submission: FormSubmission, plantRoomData?: any): string {
  const responses = submission.responses || {};
  
  let responseRows = '';
  Object.entries(responses).forEach(([fieldId, value]) => {
    const label = fieldId.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    let displayValue = '';
    
    if (typeof value === 'boolean') {
      displayValue = value ? '✓ Yes' : '✗ No';
    } else if (typeof value === 'string' && value.startsWith('data:image')) {
      displayValue = '<img src="' + value + '" style="max-width: 200px; max-height: 150px; object-fit: cover;" alt="Form photo" />';
    } else {
      displayValue = String(value) || 'No response';
    }
    
    responseRows += `
      <tr>
        <td style="padding: 12px; border-bottom: 1px solid #e5e7eb; font-weight: 600; background-color: #f8fafc; width: 35%;">${label}</td>
        <td style="padding: 12px; border-bottom: 1px solid #e5e7eb;">${displayValue}</td>
      </tr>
    `;
  });

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <title>Form Submission Report - ${submission.form_submission_id}</title>
      <style>
        body { 
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
          margin: 0; 
          padding: 30px; 
          color: #1e293b; 
          line-height: 1.6;
          background-color: #f8fafc;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          background: white;
          padding: 40px;
          border-radius: 12px;
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .header { 
          border-bottom: 3px solid #0d9488; 
          padding-bottom: 25px; 
          margin-bottom: 30px; 
          text-align: center;
        }
        .title { 
          color: #0d9488; 
          margin: 0; 
          font-size: 32px; 
          font-weight: bold; 
          letter-spacing: -0.5px;
        }
        .subtitle { 
          color: #64748b; 
          margin: 8px 0 0 0; 
          font-size: 16px;
        }
        table { 
          width: 100%; 
          border-collapse: collapse; 
          margin-top: 25px; 
          border: 1px solid #e5e7eb;
          border-radius: 8px;
          overflow: hidden;
        }
        th { 
          background: linear-gradient(135deg, #0d9488, #0f766e);
          color: white;
          padding: 15px; 
          text-align: left; 
          font-weight: 600;
          font-size: 14px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        .info-grid { 
          display: grid; 
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); 
          gap: 20px; 
          margin-bottom: 30px; 
        }
        .info-item { 
          padding: 20px; 
          background: linear-gradient(135deg, #f0fdfa, #f7fee7);
          border-radius: 10px; 
          border: 1px solid #a7f3d0;
          box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }
        .info-label { 
          font-weight: bold; 
          color: #0f766e; 
          font-size: 12px; 
          text-transform: uppercase; 
          letter-spacing: 1px; 
          margin-bottom: 5px;
        }
        .info-value { 
          color: #1e293b; 
          font-size: 16px;
          font-weight: 600; 
        }
        .signatures { 
          margin-top: 40px; 
          display: grid; 
          grid-template-columns: 1fr 1fr; 
          gap: 30px; 
        }
        .signature-box { 
          text-align: center; 
          border: 2px solid #e5e7eb; 
          padding: 20px; 
          border-radius: 12px;
          background: #fafafa;
        }
        .signature-image { 
          max-width: 250px; 
          height: 100px; 
          margin: 15px auto; 
          border: 1px solid #d1d5db;
          border-radius: 6px;
          background: white;
        }
        .footer { 
          margin-top: 50px; 
          padding-top: 25px; 
          border-top: 2px solid #e5e7eb; 
          text-align: center; 
          color: #64748b; 
          font-size: 14px; 
        }
        .status-badge {
          display: inline-block;
          padding: 6px 12px;
          background: #dcfce7;
          color: #166534;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1 class="title">Form Submission Report</h1>
          <p class="subtitle">Mech Hub Plant Room Management System</p>
          <div class="status-badge">${submission.status}</div>
        </div>
        
        <div class="info-grid">
          <div class="info-item">
            <div class="info-label">Submission ID</div>
            <div class="info-value">${submission.form_submission_id}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Asset</div>
            <div class="info-value">${submission.assets?.["Asset Name"] || 'General'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Engineer</div>
            <div class="info-value">${submission.team?.["Name"] || 'Unknown'}</div>
          </div>
          <div class="info-item">
            <div class="info-label">Date</div>
            <div class="info-value">${new Date(submission.submission_date).toLocaleDateString()}</div>
          </div>
          ${plantRoomData ? `
          <div class="info-item">
            <div class="info-label">Location</div>
            <div class="info-value">${plantRoomData.Block || 'Unknown'}</div>
          </div>
          ` : ''}
          ${submission.tasks ? `
          <div class="info-item">
            <div class="info-label">Task Type</div>
            <div class="info-value">${submission.tasks.type_of_task}</div>
          </div>
          ` : ''}
        </div>

        <table>
          <thead>
            <tr>
              <th>Field</th>
              <th>Response</th>
            </tr>
          </thead>
          <tbody>
            ${responseRows}
          </tbody>
        </table>

        ${(submission.engineer_signature || submission.client_signature) ? `
        <div class="signatures">
          ${submission.engineer_signature ? `
          <div class="signature-box">
            <h4 style="margin: 0 0 10px 0; color: #0f766e;">Engineer Signature</h4>
            <img src="${submission.engineer_signature}" alt="Engineer Signature" class="signature-image" />
            <p style="margin: 10px 0 0 0; font-weight: 600;">${submission.team?.["Name"] || 'Engineer'}</p>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #64748b;">${new Date(submission.submission_date).toLocaleDateString()}</p>
          </div>
          ` : ''}
          ${submission.client_signature ? `
          <div class="signature-box">
            <h4 style="margin: 0 0 10px 0; color: #0f766e;">Client Signature</h4>
            <img src="${submission.client_signature}" alt="Client Signature" class="signature-image" />
            <p style="margin: 10px 0 0 0; font-weight: 600;">Client Representative</p>
            <p style="margin: 5px 0 0 0; font-size: 12px; color: #64748b;">${new Date(submission.submission_date).toLocaleDateString()}</p>
          </div>
          ` : ''}
        </div>
        ` : ''}

        <div class="footer">
          <p><strong>Generated:</strong> ${new Date().toLocaleString()}</p>
          <p><strong>System:</strong> Mech Hub Plant Room Management</p>
          <p style="margin-top: 15px; font-size: 12px;">
            This report contains confidential information and is intended solely for the addressee.
          </p>
        </div>
      </div>
    </body>
    </html>
  `;
}