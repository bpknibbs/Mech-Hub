/*
  # Fetch Recent Activity Function
  
  Proxies recent activity queries through Edge Function to bypass webcontainer network restrictions
  
  1. Functionality
    - Fetches recent completed tasks, logs, submissions, and parts requests
    - Combines different activity types into unified timeline
    - Returns formatted activity data for dashboard
    
  2. Security
    - Uses service role for database access
    - Returns public activity information only
*/

import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    if (!supabaseUrl || !supabaseServiceKey) {
      console.error('Missing environment variables:', { 
        hasUrl: !!supabaseUrl, 
        hasServiceKey: !!supabaseServiceKey 
      });
      return new Response(
        JSON.stringify({ error: 'Missing Supabase configuration' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    let supabase;
    
    try {
      supabase = createClient(supabaseUrl, supabaseServiceKey);
    } catch (initError) {
      console.error('Error initializing client:', initError);
      return new Response(
        JSON.stringify({ error: 'Failed to initialize database client' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }
    
    console.log('Fetching recent activity...');

    let completedTasksResult, recentLogsResult, recentSubmissionsResult, recentPartsResult;
    
    try {
      [
        completedTasksResult,
        recentLogsResult,
        recentSubmissionsResult,
        recentPartsResult
      ] = await Promise.all([
        supabase
          .from('tasks')
          .select('id, task_id, type_of_task, date_completed')
          .eq('status', 'Completed')
          .not('date_completed', 'is', null)
          .order('date_completed', { ascending: false })
          .limit(3),
        supabase
          .from('logs')
          .select('id, log_entry, user_email, created_at')
          .order('created_at', { ascending: false })
          .limit(2),
        supabase
          .from('form_submissions')
          .select('id, form_submission_id, created_at')
          .order('created_at', { ascending: false })
          .limit(2),
        supabase
          .from('parts_requests')
          .select('id, part_name, status, created_at')
          .order('created_at', { ascending: false })
          .limit(2)
      ]);
    } catch (queryError) {
      console.error('Database query error:', queryError);
      return new Response(
        JSON.stringify({ 
          error: `Database query failed: ${queryError.message}`,
          success: false 
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const activities: any[] = [];

    // Process completed tasks
    (completedTasksResult.data || []).forEach(task => {
      activities.push({
        id: task.id,
        type: 'task_completed',
        title: 'Task Completed',
        description: `${task.type_of_task} task completed`,
        timestamp: task.date_completed,
        status: 'Completed'
      });
    });

    // Process recent logs
    (recentLogsResult.data || []).forEach(log => {
      activities.push({
        id: log.id,
        type: 'log_entry',
        title: 'Log Entry Added',
        description: log.log_entry.substring(0, 60) + (log.log_entry.length > 60 ? '...' : ''),
        timestamp: log.created_at,
        user: log.user_email
      });
    });

    // Process form submissions
    (recentSubmissionsResult.data || []).forEach(submission => {
      activities.push({
        id: submission.id,
        type: 'form_submission',
        title: 'Form Submitted',
        description: `Form ${submission.form_submission_id} submitted`,
        timestamp: submission.created_at
      });
    });

    // Process parts requests
    (recentPartsResult.data || []).forEach(request => {
      activities.push({
        id: request.id,
        type: 'parts_request',
        title: 'Parts Requested',
        description: `${request.part_name} requested`,
        timestamp: request.created_at,
        status: request.status
      });
    });

    // Sort by timestamp and return
    const sortedActivities = activities.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    ).slice(0, 8);

    return new Response(
      JSON.stringify({ 
        success: true,
        data: sortedActivities
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in fetch-recent-activity function:', error);
    return new Response(
      JSON.stringify({ 
        error: `Internal server error: ${error.message}`,
        success: false 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});