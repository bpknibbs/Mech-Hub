/*
  # Daily Task Automation Function
  
  Automatically generates maintenance tasks based on asset service frequencies and LGSR schedules
  
  1. Functionality
    - Runs daily to check asset service schedules
    - Generates PPM tasks based on asset frequency and last service date
    - Creates LGSR tasks for gas-related plant rooms based on classification
    - Assigns tasks to appropriate team members based on skills
    - Sends notifications for newly created tasks
    
  2. Schedule Generation Logic
    - Daily: Generate task if last service date + 1 day <= today
    - Weekly: Generate task if last service date + 7 days <= today
    - Fortnightly: Generate task if last service date + 14 days <= today
    - Monthly: Generate task if last service date + 30 days <= today
    - Quarterly: Generate task if last service date + 90 days <= today
    - Annually: Generate task if last service date + 365 days <= today
    
  3. LGSR Schedule Logic
    - Domestic properties: Every 12 months from last LGSR date
    - Non-domestic properties: Every 12 months from last LGSR date
    - Community halls: Every 12 months from last LGSR date
    
  4. Security
    - Uses service role for full database access
    - Validates data integrity before task creation
*/

import { createClient } from 'npm:@supabase/supabase-js@2.56.0';

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

interface Asset {
  id: string;
  "Asset ID": string;
  "Asset Name": string;
  "Asset Type": string;
  "Last Service Date": string;
  "Frequency": string;
  "Plant Room ID": string;
  "Operational": boolean;
}

interface PlantRoom {
  id: string;
  "Plant Room ID": string;
  "Block": string;
  "Plant Room Type": string;
  last_lgsr_date?: string;
  domestic_classification?: string;
}

interface TeamMember {
  id: string;
  "Name": string;
  "Email": string;
  "Skills": string[];
  "Role": string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    if (!supabaseUrl || !supabaseServiceKey) {
      return new Response(
        JSON.stringify({ error: 'Missing Supabase configuration' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    console.log('Starting daily task automation...');
    
    let totalTasksCreated = 0;
    const errors: string[] = [];
    const results: any[] = [];

    // Get current date
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    // Fetch all operational assets with service history
    const { data: assets, error: assetsError } = await supabase
      .from('assets')
      .select('*')
      .eq('"Operational"', true)
      .not('"Last Service Date"', 'is', null)
      .not('"Frequency"', 'is', null);

    if (assetsError) {
      errors.push(`Error fetching assets: ${assetsError.message}`);
    }

    // Fetch plant rooms for LGSR tasks
    const { data: plantRooms, error: plantRoomsError } = await supabase
      .from('plant_rooms')
      .select('*')
      .in('"Plant Room Type"', ['Gas Heat Generating', 'Community Hall', 'Concierge']);

    if (plantRoomsError) {
      errors.push(`Error fetching plant rooms: ${plantRoomsError.message}`);
    }

    // Fetch team members for assignment
    const { data: teamMembers, error: teamError } = await supabase
      .from('team')
      .select('*')
      .neq('"Role"', 'Viewer');

    if (teamError) {
      errors.push(`Error fetching team members: ${teamError.message}`);
    }

    // Helper function to calculate next service date
    const calculateNextServiceDate = (lastServiceDate: string, frequency: string): Date => {
      const lastDate = new Date(lastServiceDate);
      
      switch (frequency.toLowerCase()) {
        case 'daily':
          return new Date(lastDate.getTime() + (1 * 24 * 60 * 60 * 1000));
        case 'weekly':
          return new Date(lastDate.getTime() + (7 * 24 * 60 * 60 * 1000));
        case 'fortnightly':
          return new Date(lastDate.getTime() + (14 * 24 * 60 * 60 * 1000));
        case 'monthly':
          return new Date(lastDate.getTime() + (30 * 24 * 60 * 60 * 1000));
        case 'quarterly':
          return new Date(lastDate.getTime() + (90 * 24 * 60 * 60 * 1000));
        case 'annually':
          return new Date(lastDate.getTime() + (365 * 24 * 60 * 60 * 1000));
        default:
          return new Date(lastDate.getTime() + (30 * 24 * 60 * 60 * 1000)); // Default to monthly
      }
    };

    // Helper function to find best team member for task
    const findBestAssignee = (assetType: string, teamMembers: TeamMember[]): string | null => {
      // Map asset types to required skills
      const skillMapping: { [key: string]: string[] } = {
        'Fresh Water Pump': ['HVAC', 'Plumbing', 'Mechanical'],
        'Boiler': ['HVAC', 'Boiler Maintenance', 'Mechanical'],
        'Heating Circulator Pump': ['HVAC', 'Mechanical'],
        'Generator': ['Electrical', 'Generator Maintenance'],
        'Fire Panel': ['Fire Safety', 'Electrical'],
        'Gas Valve': ['HVAC', 'Boiler Maintenance']
      };

      const requiredSkills = skillMapping[assetType] || ['Mechanical'];
      
      // Find team members with matching skills
      const matchingMembers = teamMembers.filter(member => 
        member["Skills"] && requiredSkills.some(skill => member["Skills"].includes(skill))
      );

      if (matchingMembers.length > 0) {
        // Return first matching member (could implement load balancing here)
        return matchingMembers[0].id;
      }

      // Fallback to first non-viewer team member
      const fallbackMember = teamMembers.find(member => member["Role"] !== 'Viewer');
      return fallbackMember?.id || null;
    };

    // Process asset-based PPM tasks
    if (assets && assets.length > 0) {
      console.log(`Processing ${assets.length} assets for PPM tasks...`);
      
      for (const asset of assets) {
        try {
          const nextServiceDate = calculateNextServiceDate(asset["Last Service Date"], asset["Frequency"]);
          
          // Check if task is due (next service date is today or in the past)
          if (nextServiceDate <= today) {
            // Check if task already exists for this asset around this date
            const { data: existingTasks } = await supabase
              .from('tasks')
              .select('id')
              .eq('asset_id', asset.id)
              .eq('type_of_task', 'PPM')
              .gte('due_date', todayStr)
              .lte('due_date', new Date(today.getTime() + (7 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]);

            if (!existingTasks || existingTasks.length === 0) {
              // Find plant room database ID
              const { data: plantRoom } = await supabase
                .from('plant_rooms')
                .select('id')
                .eq('"Plant Room ID"', asset["Plant Room ID"])
                .single();

              if (plantRoom) {
                // Determine task priority based on how overdue the task is
                const daysOverdue = Math.floor((today.getTime() - nextServiceDate.getTime()) / (1000 * 60 * 60 * 24));
                const priority = daysOverdue > 30 ? 'High' : daysOverdue > 7 ? 'Medium' : 'Low';
                
                // Find best assignee
                const assigneeId = teamMembers ? findBestAssignee(asset["Asset Type"], teamMembers) : null;

                // Create PPM task
                const taskId = `AUTO-PPM-${asset["Asset ID"]}-${Date.now()}`;
                const { error: createError } = await supabase
                  .from('tasks')
                  .insert([{
                    task_id: taskId,
                    plant_room_id: plantRoom.id,
                    asset_id: asset.id,
                    assigned_to: assigneeId,
                    due_date: daysOverdue > 0 ? todayStr : nextServiceDate.toISOString().split('T')[0],
                    type_of_task: 'PPM',
                    status: 'Open',
                    priority,
                    notes: `Auto-generated PPM task for ${asset["Asset Name"]}. Last service: ${asset["Last Service Date"]}. ${daysOverdue > 0 ? `${daysOverdue} days overdue.` : 'Scheduled maintenance.'}`
                  }]);

                if (createError) {
                  errors.push(`Error creating PPM task for ${asset["Asset ID"]}: ${createError.message}`);
                } else {
                  totalTasksCreated++;
                  results.push({
                    type: 'PPM',
                    assetId: asset["Asset ID"],
                    assetName: asset["Asset Name"],
                    taskId,
                    daysOverdue,
                    assignedTo: assigneeId
                  });
                  
                  // Send notification if assigned
                  if (assigneeId && teamMembers) {
                    const assignee = teamMembers.find(m => m.id === assigneeId);
                    if (assignee) {
                      try {
                        await fetch(`${supabaseUrl}/functions/v1/send-notifications`, {
                          method: 'POST',
                          headers: {
                            'Authorization': `Bearer ${supabaseServiceKey}`,
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({
                            type: 'task_assigned',
                            recipientId: assigneeId,
                            recipientEmail: assignee["Email"],
                            taskId: taskId,
                            title: 'New PPM Task Assigned',
                            message: `Auto-generated PPM task for ${asset["Asset Name"]} at ${asset["Plant Room ID"]}. ${daysOverdue > 0 ? `${daysOverdue} days overdue.` : 'Scheduled maintenance.'}`,
                            priority: priority.toLowerCase()
                          })
                        });
                      } catch (notificationError) {
                        console.error('Error sending notification:', notificationError);
                      }
                    }
                  }
                }
              }
            }
          }
        } catch (error) {
          errors.push(`Error processing asset ${asset["Asset ID"]}: ${error}`);
        }
      }
    }

    // Process LGSR tasks for gas-related plant rooms
    if (plantRooms && plantRooms.length > 0) {
      console.log(`Processing ${plantRooms.length} gas plant rooms for LGSR tasks...`);
      
      for (const plantRoom of plantRooms) {
        try {
          // Determine LGSR frequency based on classification
          const isCommercial = plantRoom.domestic_classification === 'Non-Domestic';
          const lgsrFrequencyMonths = 12; // 12 months for both domestic and non-domestic
          
          // Calculate next LGSR date
          let nextLgsrDate: Date;
          if (plantRoom.last_lgsr_date) {
            const lastLgsr = new Date(plantRoom.last_lgsr_date);
            nextLgsrDate = new Date(lastLgsr.getTime() + (lgsrFrequencyMonths * 30 * 24 * 60 * 60 * 1000));
          } else {
            // If no previous LGSR, schedule for immediate attention
            nextLgsrDate = today;
          }

          // Check if LGSR task is due
          if (nextLgsrDate <= today) {
            // Check if LGSR task already exists for this plant room
            const { data: existingLgsrTasks } = await supabase
              .from('tasks')
              .select('id')
              .eq('plant_room_id', plantRoom.id)
              .eq('type_of_task', 'LGSR')
              .gte('due_date', todayStr)
              .lte('due_date', new Date(today.getTime() + (30 * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]);

            if (!existingLgsrTasks || existingLgsrTasks.length === 0) {
              // Determine priority based on how overdue
              const daysOverdue = Math.floor((today.getTime() - nextLgsrDate.getTime()) / (1000 * 60 * 60 * 24));
              const priority = daysOverdue > 60 ? 'High' : daysOverdue > 30 ? 'Medium' : 'Low';
              
              // Find team member with gas safety qualifications
              const gasEngineer = teamMembers?.find(member => 
                member["Skills"] && (
                  member["Skills"].includes('Gas Safety') ||
                  member["Skills"].includes('Boiler Maintenance') ||
                  member["Skills"].includes('HVAC')
                )
              );

              // Create LGSR task
              const lgsrTaskId = `AUTO-LGSR-${plantRoom["Plant Room ID"]}-${Date.now()}`;
              const { error: lgsrError } = await supabase
                .from('tasks')
                .insert([{
                  task_id: lgsrTaskId,
                  plant_room_id: plantRoom.id,
                  due_date: daysOverdue > 0 ? todayStr : nextLgsrDate.toISOString().split('T')[0],
                  type_of_task: 'LGSR',
                  status: 'Open',
                  priority,
                  assigned_to: gasEngineer?.id || null,
                  notes: `Auto-generated LGSR task for ${plantRoom["Block"]} (${plantRoom.domestic_classification || 'Non-Domestic'}). ${plantRoom.last_lgsr_date ? `Last LGSR: ${plantRoom.last_lgsr_date}.` : 'No previous LGSR recorded.'} ${daysOverdue > 0 ? `${daysOverdue} days overdue.` : 'Scheduled inspection.'}`
                }]);

              if (lgsrError) {
                errors.push(`Error creating LGSR task for ${plantRoom["Plant Room ID"]}: ${lgsrError.message}`);
              } else {
                totalTasksCreated++;
                results.push({
                  type: 'LGSR',
                  plantRoomId: plantRoom["Plant Room ID"],
                  plantRoomBlock: plantRoom["Block"],
                  taskId: lgsrTaskId,
                  daysOverdue,
                  classification: plantRoom.domestic_classification || 'Non-Domestic',
                  assignedTo: gasEngineer?.id || null
                });

                // Send notification if assigned
                if (gasEngineer) {
                  try {
                    await fetch(`${supabaseUrl}/functions/v1/send-notifications`, {
                      method: 'POST',
                      headers: {
                        'Authorization': `Bearer ${supabaseServiceKey}`,
                        'Content-Type': 'application/json',
                      },
                      body: JSON.stringify({
                        type: 'task_assigned',
                        recipientId: gasEngineer.id,
                        recipientEmail: gasEngineer["Email"],
                        taskId: lgsrTaskId,
                        title: 'New LGSR Task Assigned',
                        message: `Auto-generated LGSR inspection for ${plantRoom["Block"]} (${plantRoom.domestic_classification || 'Non-Domestic'}). ${daysOverdue > 0 ? `${daysOverdue} days overdue.` : 'Scheduled inspection.'}`,
                        priority: priority.toLowerCase()
                      })
                    });
                  } catch (notificationError) {
                    console.error('Error sending LGSR notification:', notificationError);
                  }
                }
              }
            }
          }
        } catch (error) {
          errors.push(`Error processing plant room ${plantRoom["Plant Room ID"]}: ${error}`);
        }
      }
    }

    // Check for overdue tasks and send alerts
    const { data: overdueTasks } = await supabase
      .from('tasks')
      .select(`
        id,
        task_id,
        due_date,
        type_of_task,
        assigned_to,
        assets("Asset Name"),
        plant_rooms("Block"),
        team("Email", "Name")
      `)
      .neq('status', 'Completed')
      .lt('due_date', todayStr);

    if (overdueTasks && overdueTasks.length > 0) {
      console.log(`Found ${overdueTasks.length} overdue tasks, sending alerts...`);
      
      for (const task of overdueTasks) {
        if (task.team && (task.team as any)["Email"]) {
          const daysOverdue = Math.floor((today.getTime() - new Date(task.due_date).getTime()) / (1000 * 60 * 60 * 24));
          
          // Send overdue alert (but limit to avoid spam - only send on specific intervals)
          if (daysOverdue === 1 || daysOverdue === 3 || daysOverdue === 7 || (daysOverdue % 7 === 0 && daysOverdue <= 30)) {
            try {
              await fetch(`${supabaseUrl}/functions/v1/send-notifications`, {
                method: 'POST',
                headers: {
                  'Authorization': `Bearer ${supabaseServiceKey}`,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  type: 'task_overdue',
                  recipientId: task.assigned_to,
                  recipientEmail: (task.team as any)["Email"],
                  taskId: task.id,
                  title: 'Task Overdue Alert',
                  message: `Your ${task.type_of_task} task for ${(task.assets as any)?.["Asset Name"] || 'general maintenance'} at ${(task.plant_rooms as any)?.["Block"] || 'plant room'} is ${daysOverdue} days overdue.`,
                  priority: 'high'
                })
              });
            } catch (notificationError) {
              console.error('Error sending overdue notification:', notificationError);
            }
          }
        }
      }
    }

    console.log(`Daily automation completed. Created ${totalTasksCreated} tasks.`);

    // Run DRS optimization for unassigned tasks
    let optimizationResult = null;
    try {
      const optimizationResponse = await fetch(`${supabaseUrl}/functions/v1/daily-drs-optimization`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseServiceKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({})
      });

      if (optimizationResponse.ok) {
        optimizationResult = await optimizationResponse.json();
        console.log(`DRS optimization completed: ${optimizationResult.tasksAssigned} tasks auto-assigned`);
      }
    } catch (drsError) {
      console.error('Error running DRS optimization:', drsError);
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        tasksCreated: totalTasksCreated,
        tasksAutoAssigned: optimizationResult?.tasksAssigned || 0,
        overdueTasksFound: overdueTasks?.length || 0,
        results,
        drsOptimization: optimizationResult,
        errors,
        processedAssets: assets?.length || 0,
        processedPlantRooms: plantRooms?.length || 0,
        runDate: todayStr
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in daily task automation:', error);
    return new Response(
      JSON.stringify({ 
        error: `Internal server error: ${error.message}`,
        success: false 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});